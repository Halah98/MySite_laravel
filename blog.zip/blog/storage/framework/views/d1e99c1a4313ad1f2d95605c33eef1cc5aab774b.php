<section>
		  <div  id="portfolio" class="sectiontitle">
			<h6 class="heading">Previous projects Portfolio</h6>
			<p>these are some of Previous projects created by me </p>
		  </div>
		  
		  <ul   class="nospace group overview">
			<li class="one_third">
			  <figure><a href="#"><img src="/styling/HCI.jpg"></a>
				<figcaption>
				  <h6 class="heading">HCI</h6>
				  <p>creating a visualization that shows the number of arrivals in the top 10 countries.</p>
				</figcaption>
			  </figure>
			</li>
			<li class="one_third">
			  <figure><a href="#"><img src="/styling/BENGO.png"></a>
				<figcaption>
				  <h6 class="heading">Web System</h6>
				  <p>BINGO website is help you to decide the suitable activity for your children to enjoying also learn and have fun with it.</p>
				</figcaption>
			  </figure>
			</li>
			<li class="one_third">
			  <figure><a href="#"><img src="/styling/GP2.png"></a>
				<figcaption>
				  <h6 class="heading">Graduation Project</h6>
				  <p>Deep Learning based Chatbot for Corona-COVID 19 Assistance <br>
					An Android application built using Python programming language and flutter.</p>
				</figcaption>
			  </figure>
			</li>
		  </ul>
		  
		</section><?php /**PATH D:\XAMPP\htdocs\CBT\laravel\blog\resources\views/partials/portfolio.blade.php ENDPATH**/ ?>