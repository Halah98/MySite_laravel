<div id="contact" class="wrapper row3" >
	  <section class="hoc container clear"> 
		<div class="sectiontitle">
		  <a class="btn" onclick="showform();">Contact me &raquo;</a>
		</div>
		<div id="formi" class="cover_l">
            <!-- Starting form -->
	   	  <form method="post" action="#" class="row2"  onsubmit="validate();">
			 <h6 class="heading">Enter your Information</h6> 
             <!-- First row-->
             <div class="row">
                <div class="col-md-6">
                   <input id="first_name" class="btmspace-15 form-control" type="text"     placeholder="Enter Your Name" >
                   <div id="name_alert" class="alert">Your name is smaller than 4 characters !.</div>
                </div>
                <div class="col-md-6">
                   <input id="email_"     class="btmspace-15 form-control" type="Email"    placeholder="Enter Your Email">
                   <div id="email_alert" class="alert">Incorrect email..</div>
                </div>
            </div>
            <!--END 1 ROW -->
            <!-- Second Row -->
            <div class="row">
                <div class="col-md-6">        
                    <select id="gender" class="btmspace-15 form-control">
                        <option value="">-Select Your Gender-</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                    <div id="gender_alert" class="alert">You must choose your gender!!</div>
                </div>
                <div class="col-md-6">
                    <input id="subject" class="btmspace-15 form-control" type="text"     placeholder="Enter Your subject" >
                    <div id="subject_alert" class="alert">Your have to write subject..</div>
                </div>
            </div>
            <!-- END 2 ROW -->
              <span class="counter_">140</span>
              <input id="comments"   class="btmspace-15 form-control" type="textarea" placeholder="Enter Your Comment"><br>
              <div id="comments_alert_more" class="alert">Your comment is more then accabtanle</div>
              <div id="comments_alert_less" class="alert">Your comment is less then accabtanle</div><br>
              <input id="bn1"   class="btn btn-block"  type="button"   value="Send">          
           
            <!-- The end of the form -->
		  </form> 
		</div>
	  </section>
	</div><?php /**PATH D:\XAMPP\htdocs\CBT\laravel\blog\resources\views/partials/_form.blade.php ENDPATH**/ ?>