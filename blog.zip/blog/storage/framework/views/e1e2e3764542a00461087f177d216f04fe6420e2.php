
<div class="wrapper row1">
	  <header id="header" class="hoc clear"> 
		<div  id="logo"   class="fl_left">
		  <h1><a href="index">Halah's</a></h1>
		  <p>resume</p>
	    </div>
	  </header>
	  <nav id="mainav" class="hoc clear"> 
		<ul   class="clear">
		  <li class="active"><a href="index">Home</a></li>
		  <li><a href="#about">About</a></li>
		  <li><a href="#portfolio">Portfolio</a></li>
		  <li><a href="#contact">Contact</a></li>
		</ul>
	  </nav>
	</div><?php /**PATH D:\XAMPP\htdocs\CBT\laravel\blog\resources\views/partials/_navbar.blade.php ENDPATH**/ ?>