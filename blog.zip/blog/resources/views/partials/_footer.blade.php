<div class="wrapper row4">
<footer id="footer" class="hoc clear"> 
		<div  class="cover_l first">
		  <h6 class="heading">Information</h6>
		  <ul class="nospace btmspace-30 linklist contact">
			<li>Riyadh</li>
			<li> +966 561881098</li>
			<li>halah.almarshad@gmail.com</li>
		  </ul>
		  <ul class="faico clear">
			<li><a class="faicon-twitter" href="http://linkedin.com/in/halah-almarshad-4725a01a2"target="_blank"><img src="/styling/in.png"></a></li>
			<li><a class="faicon-linkedin" href="https://twitter.com/explore"><img src="/styling//te.png"></a></li>
		  </ul>
		</div>		
    </div>
	<div class="wrapper row5">
	  <div id="copyright" class="hoc clear"> 
		<p>Copyright &copy; 2021 - build by <a href="#about">Halah AlMarshad</p>
	  </div>
	</div>
 </footer>