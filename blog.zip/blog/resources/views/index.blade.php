<!DOCTYPE html>
<html>
	<head>
		<title>My Website</title>
		<meta charset="utf-8">
		
          <!-- Bootstrap Css link -->
          <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" 
          integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
       
         <!-- JQuery JS-->
         <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        
         <!-- my edite Css -->
        <link rel="stylesheet" type="text/css" href="{{ url('/styling/layout.css') }}" />
	</head>

    <body id="top">  

        <!-- logo & barnav -->
        @include('partials._navbar')
	
        <!--  pic with text -->
        <div class="wrapper bgded overlay" style="background-image:url('/styling/01.jpg');">
        <div id="pageintro" class="hoc clear"> 
            <article>
            <p>welcome to </p>
            <h3 class="heading">halah AlMarshad</h3>
            <p>website</p>
            </article>
        </div>
        </div>
	
        <!-- main body -->
        <div  class="wrapper row3">
        <main class="hoc container clear"> 
		
		<!-- About me section -->
		<section id="introblocks" >
		  <div id="about" class="sectiontitle" >
			<h6 class="heading">About me !</h6>
		  </div>
		  <ul class="nospace group">
			<li class="one_third first">
				<img class="fl_left" src="/styling/imam.png"> 
			</li>
			<li class="cover_l">
			  <article><i class="fa fa-linode"></i>
				<h6 class="heading font-x1"><a href="#">Cover letter</a></h6>
				<p>My name is halah almarshad I am student at imam Mohammed bin saud Islamic University in information technology major.<br> 
				   To introduce myself on personal level , I consider myself with high sense of responsibility so I like to complete my work in the best way , and I loves to learn and familiarize myself with what is new.<br>
				   And when we come on technical level and the field that I preferred, I preferred building applications and database and interfaces design , also I am interested in cybersecurity and Artificial Intelligence.<br>
					<h6>One of my strengths is that I am a good researcher and am highly skilled in self learning.</h6>
				</p>
			  </article>
			</li>
		  </ul>
		</section>
		
		
		<hr class="btmspace-80">
        <!--portfolio section -->
		@include('partials.portfolio')

	    </main>
	    </div>	
	    <hr>

        <!-- form section-->
        @include('partials._form')
	    

        <!-- footer -->
        @include('partials._footer')

	    <!--my Script Editing -->
        <script src="/styling/script.js"></script>
	</body>
</html>